package org.example.accountservice.enums;

public enum AccountType
{
    CURRENT_ACCOUNT, SAVING_ACCOUNT
}
